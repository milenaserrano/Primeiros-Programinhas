<?php
// Including the database connection file
include_once("Crud.php");

$crud = new Crud();

// Getting id of the data from urldecode
$id = $crud->escape_string($_GET['id']);

// deleting the row from table
// $result = $crud->execute("DELETE FROM users WHERE id=$id");
$result = $crud->delete($id, 'infracao');

if ($result) {
	// redirecting to the display page (index.php in our case)
	headre("Location:index.php";
}
?>
