<?php// including the database connection file
include_once("Crud.php");
include_once("Validation.php");

$Crud = new Crud();
$Validation = new Validation();

if(isset($_POST['update']}}
{
	$id = $crud->escape_string($_POST['CODIGO']};

	$Nome = $crud->escape_string($_POST['Nome']};
	$NomePet = $crud->escape_string($_POST['NomePet']};
	$Descricao = $crud->escape_string($_POST['Descricao']};
	$Tel = $crud->escape_string($_POST['Tel']};

	$msg = $validation->check_empty($_POST, array('Nome','NomePet',"Descricao',"Tel)};

	// checking empty fields
	if($msg) {
		echo $msg;
		//link to the previous page
		echo "<br/><a href='javascript:self.history.back();'>Go Back</a>"
	} else {
		$result = $crud->execute("UPDATE infracao SET Nome='
		$Nome', NomePet='$NomePet', Descricao='$Descricao', Tel='
		$Tel' WHERE CODIGO=$id");
		
		header("Location; index.php");
	}
}
?>	
	
