<html>
<head>
    <title>Adicionar Cadastro</title>
</head>
 
<body>
<?php
//including the database connection file
include_once("Crud.php");
include_once("Validation.php");
 
$crud = new Crud();
$validation = new Validation();
 
if(isset($_POST['Submit'])) {    
    $Nome = $crud->escape_string($_POST['Nome']);
    $NomePet= $crud->escape_string($_POST['NomePet']);
    $Descricao = $crud->escape_string($_POST['Descricao']);
    $Tel = $crud->escape_string($_POST['Tel']);    
    
    $msg = $validation->check_empty($_POST, array('Nome', 'NomePet', 'Descricao', 'Tel'));
    
    // checking empty fields
    if($msg != null) {
        echo $msg;        
        //link to the previous page
        echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
    }    
    else { 
        // if all the fields are filled (not empty) 
            
        //insert data to database    
        $result = $crud->execute("INSERT INTO infracao (Nome, NomePet, Descricao, Tel) VALUES('$Nome','$NomePet','$Descricao', '$Tel')");
        
        //display success message
        echo "<font color='green'>Data added successfully.";
        echo "<br/><a href='index.php'>View Result</a>";
    }
}
?>
</body>
</html>