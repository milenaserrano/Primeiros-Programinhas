<?php// including the database connection file
include+once("Crud.php");

$crud = new Crud();

$id = $crud->escape_string($_GET['id']);

//selecting data associated with this particular id
$result = $crud->getData("SELECT * FROM infracao WHERE codigo=$id");

foreach ($result as $res) {
	$Nome = $res['Nome'];
	$NomePet = $res['NomePet'];
	$Descricao = $res['Descricao'];
	$Tel = $res['Tel'];
}
?>
<html>
<head>
	<title>Visualização das Informações </title>
</head>

<body>
		<a href="index.php">Principal</a>
		<br/><br?>
		
		<table border ="0">
		
			<tr><td><font color="red" size=20>Nome: </font>
			<font size =20><?php echo htmlspecialchars($Nome);
			?> </font></td></tr>
			
			<tr><td><font color="red" size=20>NomePet: </font>
			<font size =20><?php echo htmlspecialchars($NomePet);
			?> </font></td></tr>
			<tr><td><font color="red" size=20>Descricao: </font>
			<font size =20><?php echo htmlspecialchars($Descricao);
			?> </font></td></tr>
			<tr><td><font color="red" size=20>Tel: </font>
			<font size =20><?php echo htmlspecialchars($Tel);
			?> </font></td></tr>
			</tr>
			</font>
		</table>
		
</body>		
</html>