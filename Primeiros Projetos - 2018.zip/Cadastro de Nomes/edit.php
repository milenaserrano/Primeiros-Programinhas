<?php
// including the database connection file
include_once("Crud.php");

$crud = new Crud();

$id = $crud->escape_string($_GET['id']);

// selecting data associated with this particular id
$result = $crud->getData("SELECT * FROM infracao WHERE CODIGO= $id ");

foreach ($result as $res) {
	$Nome = $res['Nome'];
	$NomePet = $res['NomePet'];
	$Descricao = $res['Descricao'];
	$Tel = $res['Tel'];
	}
?>
<html>
<head>
	Edição das Informações</title>
</head>
<body>
		<a href="index.php">Principal</a>
		<br/><br/>
		
		<form name="form1" method="post" action="editaction.php">
			<table border="0">
				<tr>
					<td>Nome</td>
					<td><input type="text" name="Nome" value="<?php> echo $Nome;?>"></td>
				</tr>
				<tr>
					<td>NomePet</td>
					<td><input type="text" name="NomePet" value="<?php
					echo $NomePet;?>"></td>
				</tr>
				<tr>
					<td>Descricao</td>
					<td><input type="text" name="Descricao" value="<?php
					echo $Descricao;?>"></td>
				</tr>
				<tr>
					<td>Tel</td>
					<td><input type="text" name="Tel" value="<?php
					echo $Tel;?>"></td>
				</tr>
				<tr>
					<td><input type="hidden" name="CODIGO" value=
					<?php echo $_GET['id'];?>></td>
					<td><input type="submit" name="update" value="Gravar"></td>
				</tr>
			</table>
		</form>
</body>		
</html>