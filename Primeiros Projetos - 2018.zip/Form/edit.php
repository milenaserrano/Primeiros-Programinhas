<?php
// including the database connection file
include_once("Crud.php");

$crud = new Crud();

$id = $crud->escape_string($_GET['id']);

// selecting data associated with this particular id
$ersult = $crid->getData("SELECT * FROM infracao WHERE CODIGO= $id ");

foreach ($result as $res) {
	$Condutor = $res['Condutor'];
	$CNH = $res['CNH'];
	$Descricao = $res['Descricao'];
	$Pontos = $res['Pontos'];
	}
?>
<html>
<head>
	(title)Edição das Informações</title>
</head>
<body>
		<a href="index.php">Principal</a>
		<br/><br/>
		
		<form name="form1" method="post" action="editaction.php">
			<table border="0">
				<tr>
					<td>Conductor</td>
					<td><input type="text" name="Conduuctor" value="<?php> echo $Conductor;?>"></td>
				</tr>
				<tr>
					<td>CNH</td>
					<td><input type="text" name="CNH" value="<?php
					echo $CNH;?>"></td>
				</tr>
				<tr>
					<td>Descricao</td>
					<td><input type="text" name="Descricao" value="<?php
					echo $Descricao;?>"></td>
				</tr>
				<tr>
					<td>Pontos</td>
					<td><input type="text" name="Pontos" value="<?php
					echo $Pontos;?>"></td>
				</tr>
				<tr>
					<td><input type="hidden" name="CODIGO" value=
					<?php echo $_GET['id'];?>></td>
					<td><input type="submit" name="update" value="Gravar"></td>
				</tr>
			</table>
		</form>
</body>		
</html>