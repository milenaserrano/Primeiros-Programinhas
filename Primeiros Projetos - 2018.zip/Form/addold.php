﻿<?php
//including the database connection file
include_once("Crud.php");
include_once("Validation.php");

$crud = new Crud();
$validation = new Validation();

if(isset($_POST['Submit'])) {
	$Condutor =  $crud->escape_string($_POST['Condutor']);
	$CNH = 		 $crud->escape_string($_POST['CNH']);
	$Descricao = $crud->escape_string($_POST['Descricao']);
	$Pontos =    $crud->escape_string($_POST['Pontos']);
	
	$msg = $validation->check_empty($_POST, array('Condutor', 'CNH', 'Descricao', 'Pontos'));

	//checking empty fields
	if($msg != null) {
		echo $msg;
		//link to the previous page
		echo "<br/><a href='javascript:self.history.back();'> Go Back</a>";
	}
	else{
		// if all the fields are filled (not empty)
		echo "<font color='green'>Data added successfully.";
		// insert data to database
		$result = $crud->execute("INSERT INTO infracao (Condutor,CNH,Descricao,Pontos) VALUES ('$Condutor','$CNH','$Descricao','$Pontos')");
		
		//displat sucess message
		echo "<font color='green'>Data added successfully.";
		echo "<br/><a href='index.php'>View Result</a>";
	}
}
?>
</body>
</html>

