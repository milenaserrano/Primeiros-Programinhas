<?php
  include_once "Crud.php";
  $crud = new Crud();
  
  $query = "SELECT * FROM infracao ORDER BY Codigo DESC";
  $result = $crud->getData($query);
  
?>

<html>
<head>
	<title>Homepage</title>
</head>

<body>

<a href="add.html">Inserir novos Dados</a><br/><br/>

	<table width='80%' border=0>
	
	<tr bgcolor='#CCCCCC'>
		<td>Condutor</td>
		<td>CNH</td>
		<td>Infração</td>
		<td>Pontos</td>
		<td>Ações</td>
	</tr>
	<?php
	foreach ($result as $key => $res) {
			echo "<tr>";
			echo "<td>".$res['Condutor']."</td>";
			echo "<td>".$res['CNH']."</td>";
			echo "<td>".$res['Descricao']."</td>";
			echo "<td>".$res['Pontos']."</td>";
			echo "<td><a href=\"edit.php?id=$res[Codigo]\">Edit</a> | "
					. "<a href=\"delete.php?id=$res[Codigo]\"
					onClick=\"return confirm('Confirma apagar a informação?)\">Delete</a>"
					."<a href=\"view.php?id=$res[Codigo]\">Visualizar</a></td>";
	}
	?>
	</table>
</body>
</html>	
			