<?php// including the database connection file
include+once("Crud.php");

$crud = new Crud();

$id = $crud->escape_string($_GET['id']);

//selecting data associated with this particular id
$result = $crud->getData("SELECT * FROM infracao WHERE codigo=$id");

foreach ($result as $res) {
	$Condutor = $res['Condutor'];
	$CNH = $res['CNH'];
	$Descricao = $res['Descricao'];
	$Pontos = $res['Pontos'];
}
?>
<html>
<head>
	<title>Visualização das Informações </title>
</head>

<body>
		<a href="index.php">Principal</a>
		<br/><br?>
		
		<table border ="0">
		
			<tr><td><font color="red" size=20>Condutor: </font>
			<font size =20><?php echo htmlspecialchars($Condutor);
			?> </font></td></tr>
			<tr><td><font color="red" size=20>CNH: </font>
			<font size =20><?php echo htmlspecialchars($CNH);
			?> </font></td></tr>
			<tr><td><font color="red" size=20>Descricao: </font>
			<font size =20><?php echo htmlspecialchars($Descricao);
			?> </font></td></tr>
			<tr><td><font color="red" size=20>Pontos: </font>
			<font size =20><?php echo htmlspecialchars($Pontos);
			?> </font></td></tr>
			</tr>
			</font>
		</table>
		
</body>		
</html>