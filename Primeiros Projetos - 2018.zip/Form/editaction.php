<?php// including the database connection file
include_once("Crud.php");
include_once("Validation.php");

$Crud = new Crud();
$Validation = new Validation();

if(isset($_POST['update']}}
{
	$id = $crud->escape_string($_POST['CODIGO']};

	$Condutor = $crud->escape_string($_POST['Condutor']};
	$CNH = $crud->escape_string($_POST['CNH']};
	$Descricao = $crud->escape_string($_POST['Descricao']};
	$Pontos = $crud->escape_string($_POST['Pontos']};

	$msg = $validation->check_empty($_POST, array('Condutor','CNH',"Descricao',"Pontos)};

	// checking empty fields
	if($msg) {
		echo $msg;
		//link to the previous page
		echo "<br/><a href='javascript:self.history.back();'>Go Back</a>"
	} else {
		$result = $crud->execute("UPDATE infracao SET Condutor='
		$Condutor', CNH='$CNH', Descricao='$Descricao', Pontos='
		$Pontos' WHERE CODIGO=$id");
		
		header("Location; index.php");
	}
}
?>	
	
