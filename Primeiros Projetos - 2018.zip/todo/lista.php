<?php
$servername = "localhost";
$database = "bancojob";
$username = "root";
$password = "";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$consulta = "select * from tab_todo";
$resultado = mysqli_query($conn, $consulta);
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Listagem de TODO</title>
</head>
<body>
<?php
 if (mysqli_num_rows($resultado) > 0) {
            while($linha = mysqli_fetch_assoc($resultado)) {
               echo "Nome: " . $linha["nome"] . " Data: " . $linha["data"] . "<br>";
            }
         } else {
            echo "0 results";
         }
         mysqli_close($conn);
      ?>
	  
	  
<br>
<h1><a href="index.html">.:Voltar:.</a></h1>
</body>
</html>




