<?php

$nome = $_POST['nome'];
$data = $_POST['data'];
$descri = $_POST['descri'];

$servername = "localhost";
$database = "bancojob";
$username = "root";
$password = "";



// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$sql = "INSERT INTO tab_todo (nome, descri, data) VALUES ('$nome', '$descri', '$data' )";
if (mysqli_query($conn, $sql)) {
      echo "Informação gravada com sucesso!!!";
} else {
      echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
mysqli_close($conn);
?>
