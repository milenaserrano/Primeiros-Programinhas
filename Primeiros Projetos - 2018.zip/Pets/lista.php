<?php
$servername = "localhost";
$database = "bd";
$username = "root";
$password = "";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$consulta = "select * from tab";
$resultado = mysqli_query($conn, $consulta);
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Listagem de Cadastros</title>
</head>
<body>

<?php
 if (mysqli_num_rows($resultado) >= 0) {
            while($linha = mysqli_fetch_assoc($resultado)) {
               echo 
			   "Nome: "  . $linha["nomepet"] .
			   " Raça: " . $linha["racapet"] .
               " Dono do Pet: " . $linha["nomedono"] .
			   " Data de Nascimento do Pet: " . $linha["datanascpet"] .
			   "<br>";
            }
         } else {
            echo "0 results";
         }
         mysqli_close($conn);
      ?>
</body>
</html>