<?php

$nomepet = $_POST['nomepet'];
$racapet = $_POST['racapet'];
$nomedono = $_POST['nomedono'];
$datanascpet = $_POST['datanascpet'];

$servername = "localhost";
$database = "bd";
$username = "root";
$password = "";

// Conectar:
$conn = mysqli_connect($servername, $username, $password, $database);

// Checar conexão:
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$sql = "INSERT INTO tab (nomepet, racapet, nomedono, datanascpet) VALUES ('$nomepet', '$racapet', '$nomedono', '$datanascpet' )";
if (mysqli_query($conn, $sql)) {
      echo "Cadastro gravado com sucesso!!!";
} else {
      echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
mysqli_close($conn);
?>
